import traci
import random


def run():
    global ambulance_count  # ВАЖНО: объявляем как global

    sumo_cmd = ["sumo-gui", "-c", "config_map1.sumocfg"]
    traci.start(sumo_cmd)

    step = 0
    ambulance_count = 0
    accident_count = 0
    dynamic_vehicle_count = 0

    print("Запуск симуляции...")
    print("Скорые будут создаваться каждые 100 шагов!")
    print("Добавлена дневная динамика загруженности дорог\n")

    try:
        while step < 1000 and traci.simulation.getMinExpectedNumber() > 0:
            traci.simulationStep()

            # === ДНЕВНАЯ ДИНАМИКА ЗАГРУЖЕННОСТИ ===

            # Утренний час пик (0-300 сек): высокая интенсивность
            if 0 <= step < 300:
                if step % 3 == 0 and random.random() < 0.7:
                    try:
                        veh_id = f"morning_{dynamic_vehicle_count}"
                        routes = traci.route.getIDList()
                        if routes:
                            traci.vehicle.add(veh_id, routeID=routes[0])
                            dynamic_vehicle_count += 1
                    except:
                        pass

            # Обед (300-600 сек): средняя интенсивность
            elif 300 <= step < 600:
                if step % 8 == 0 and random.random() < 0.4:
                    try:
                        veh_id = f"afternoon_{dynamic_vehicle_count}"
                        routes = traci.route.getIDList()
                        if routes:
                            traci.vehicle.add(veh_id, routeID=routes[0])
                            dynamic_vehicle_count += 1
                    except:
                        pass

            # Вечерний час пик (600-900 сек): очень высокая интенсивность
            elif 600 <= step < 900:
                if step % 2 == 0 and random.random() < 0.8:
                    try:
                        veh_id = f"evening_{dynamic_vehicle_count}"
                        routes = traci.route.getIDList()
                        if routes:
                            traci.vehicle.add(veh_id, routeID=routes[0])
                            dynamic_vehicle_count += 1
                    except:
                        pass

            # Ночь (900+ сек): низкая интенсивность
            else:
                if step % 15 == 0 and random.random() < 0.2:
                    try:
                        veh_id = f"night_{dynamic_vehicle_count}"
                        routes = traci.route.getIDList()
                        if routes:
                            traci.vehicle.add(veh_id, routeID=routes[0])
                            dynamic_vehicle_count += 1
                    except:
                        pass

            # АВАРИЯ (каждые 50 шагов)
            if step % 50 == 0 and step > 0:
                vehicles = traci.vehicle.getIDList()
                moving = [v for v in vehicles if traci.vehicle.getSpeed(v) > 1]
                if moving:
                    victim = random.choice(moving)
                    traci.vehicle.setSpeed(victim, 0)
                    traci.vehicle.setColor(victim, (255, 0, 0, 255))
                    accident_count += 1
                    print(f"💥 АВАРИЯ #{accident_count}: {victim}")

            # СКОРАЯ (КАЖДЫЕ 100 ШАГОВ)
            if step % 100 == 0 and step > 0:
                try:
                    routes = traci.route.getIDList()
                    if routes:
                        # Создаем тип (если еще не создан)
                        try:
                            traci.vehicletype.copy("DEFAULT_VEHTYPE", "ambulance")
                        except:
                            pass

                        traci.vehicletype.setColor("ambulance", (255, 255, 255, 255))
                        traci.vehicletype.setMaxSpeed("ambulance", 30)

                        # УНИКАЛЬНЫЙ ID
                        amb_id = f"ambulance_{ambulance_count}"
                        traci.vehicle.add(amb_id, routeID=routes[0], typeID="ambulance")

                        print(f"🚑 СКОРАЯ #{ambulance_count + 1} ({amb_id}) создана на шаге {step}")
                        ambulance_count += 1
                except Exception as e:
                    print(f" Ошибка создания скорой: {e}")

            # Статистика каждые 100 шагов
            if step % 100 == 0:
                vehicles = traci.vehicle.getIDList()
                print(
                    f"📊 Шаг {step}: всего машин = {len(vehicles)}, скорых = {ambulance_count}, добавлено динамически = {dynamic_vehicle_count}")

            step += 1

    except KeyboardInterrupt:
        print("\n⚠️  Прервано")

    finally:
        traci.close()
        print(f"\n✅ Завершено!")
        print(f"💥 Аварий: {accident_count}")
        print(f"🚑 Скорых: {ambulance_count}")
        print(f" Динамически добавлено машин: {dynamic_vehicle_count}")


if __name__ == "__main__":
    run()