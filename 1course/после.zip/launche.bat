@echo off
cd /d "B:\Sumo\после\"
python dynamic_events.py
pause